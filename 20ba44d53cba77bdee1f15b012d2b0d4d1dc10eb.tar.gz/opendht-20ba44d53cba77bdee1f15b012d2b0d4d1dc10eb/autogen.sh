git submodule update --init
autoreconf --install --verbose -Wall
